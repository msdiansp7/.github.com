var shubham = 7;
{console.log( shubham );}
